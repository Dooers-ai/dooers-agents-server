"""Validador portátil: só lê o bundle, sem fonte TS, rede, credencial ou repo irmão."""
import hashlib
import json
import re
import sys
from pathlib import Path

from ada_url import URL
from jsonschema import Draft202012Validator, FormatChecker, ValidationError, validators

sys.dont_write_bytecode = True

from semantics import ECMASCRIPT_WHITESPACE, SEMANTIC_RULES, semantic_valid


class ContractError(Exception):
    pass


def fail(code):
    raise ContractError(code)


def read_bundle(directory):
    directory = Path(directory)
    manifest_path = directory / "bundle-manifest.json"
    if manifest_path.is_symlink():
        fail("BUNDLE_SYMLINK_FORBIDDEN")
    manifest = json.loads(manifest_path.read_bytes())
    if manifest.get("protocol_version") != 1 or manifest.get("schema_version") != 1:
        fail("BUNDLE_VERSION_UNSUPPORTED")
    files = manifest["artifacts"]
    expected = set(files) | {"bundle-manifest.json"}
    actual = set()
    for path in directory.rglob("*"):
        if path.is_symlink():
            fail("BUNDLE_SYMLINK_FORBIDDEN")
        if path.is_file():
            # A cópia executável não deve criar pycache dentro do artefato imutável.
            actual.add(path.relative_to(directory).as_posix())
    if actual != expected:
        fail("BUNDLE_INVENTORY_DRIFT")
    verified = {}
    for name, checksum in files.items():
        if name.startswith("/") or ".." in Path(name).parts or "\\" in name:
            fail("BUNDLE_PATH_INVALID")
        data = (directory / name).read_bytes()
        if hashlib.sha256(data).hexdigest() != checksum:
            fail("BUNDLE_CHECKSUM_MISMATCH")
        verified[name] = data
    return verified


def utf16(value):
    raw = value.encode("utf-16-le", errors="surrogatepass")
    return "".join(chr(raw[index] + 256 * raw[index + 1]) for index in range(0, len(raw), 2))


def js_pattern(pattern):
    # A baseline só exporta regex sem flags Unicode. Python \s inclui U+0085,
    # mas ECMAScript inclui BOM e exclui U+0085. Traduzir também \d/\w.
    whitespace = "".join("\\u%04x" % ord(char) for char in ECMASCRIPT_WHITESPACE)
    return pattern.replace(r"\S", "[^" + whitespace + "]").replace(r"\s", "[" + whitespace + "]").replace(r"\d", "[0-9]").replace(r"\w", "[a-zA-Z0-9_]")


def pattern_keyword(validator, pattern, instance, schema):
    if isinstance(instance, str) and re.search(js_pattern(pattern), utf16(instance)) is None:
        yield ValidationError("PATTERN_INVALID")


def length_keyword(validator, bounds, instance, schema):
    if isinstance(instance, str):
        length = len(utf16(instance))
        if length < bounds.get("min", 0) or ("max" in bounds and length > bounds["max"]):
            yield ValidationError("STRING_LENGTH_INVALID")


def parse_url(value):
    try:
        return URL(value)
    except (ValueError, TypeError, UnicodeError):
        return None


def url_keyword(validator, constraints, instance, schema):
    if not isinstance(instance, str):
        return
    parsed = parse_url(instance)
    if parsed is None:
        yield ValidationError("URL_INVALID")
        return
    for key in ("protocol", "hostname"):
        if key not in constraints:
            continue
        definition = constraints[key]
        flags = definition["flags"]
        if any(flag not in "im" for flag in flags):
            fail("URL_REGEX_FLAGS_UNSUPPORTED")
        actual = parsed.protocol.rstrip(":") if key == "protocol" else parsed.hostname
        regex_flags = (re.IGNORECASE if "i" in flags else 0) | (re.MULTILINE if "m" in flags else 0)
        if not re.search(js_pattern(definition["source"]), actual, regex_flags):
            yield ValidationError("URL_CONSTRAINT_INVALID")


format_checker = FormatChecker()


@format_checker.checks("uri")
def url_format(value):
    # Zod usa WHATWG URL, não o formato RFC3986 mais estrito de jsonschema.
    return not isinstance(value, str) or parse_url(value) is not None


@format_checker.checks("date-time")
def datetime_format(value):
    if not isinstance(value, str):
        return True
    match = re.fullmatch(r"([0-9]{4})-([0-9]{2})-([0-9]{2})T([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.[0-9]+)?)?Z", value)
    if not match:
        return False
    year, month, day, hour, minute, second = (int(part or 0) for part in match.groups())
    if not 1 <= month <= 12 or hour > 23 or minute > 59 or second > 59:
        return False
    days = (31, 29 if year % 4 == 0 and (year % 100 != 0 or year % 400 == 0) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
    return 1 <= day <= days[month - 1]


def build_validator(rules):
    def semantics_keyword(validator, name, instance, schema):
        if name not in SEMANTIC_RULES:
            fail("SEMANTIC_RULE_UNKNOWN")
        # Semântica do nó só roda com estrutura e filhos válidos. Remove apenas
        # a keyword deste nó, preservando regras de arrays/anyOf aninhados.
        structure = {key: value for key, value in schema.items() if key != "x-maestro-semantic"}
        if not validator.evolve(schema=structure).is_valid(instance):
            return
        try:
            valid = semantic_valid(name, instance, rules)
        except (KeyError, TypeError, ValueError, OverflowError):
            valid = False
        if not valid:
            yield ValidationError("SEMANTIC_INVALID:" + name)
    return validators.extend(Draft202012Validator, {
        "x-maestro-semantic": semantics_keyword,
        "x-maestro-string-length": length_keyword,
        "x-maestro-url": url_keyword,
        "pattern": pattern_keyword,
    })


def inspect_schema(value):
    if isinstance(value, list):
        for child in value:
            inspect_schema(child)
    elif isinstance(value, dict):
        if "x-maestro-semantic" in value and value["x-maestro-semantic"] not in SEMANTIC_RULES:
            fail("SEMANTIC_RULE_UNKNOWN")
        if isinstance(value.get("format"), str) and value["format"] not in format_checker.checkers:
            fail("FORMAT_UNSUPPORTED")
        if "$ref" in value and not value["$ref"].startswith("#/"):
            fail("SCHEMA_EXTERNAL_REF_FORBIDDEN")
        for key, child in value.items():
            if key not in ("const", "enum", "default", "examples"):
                inspect_schema(child)


def validate_bundle(directory):
    contents = read_bundle(directory)
    schemas = json.loads(contents["schemas.json"])["schemas"]
    fixtures = json.loads(contents["fixtures.json"])["cases"]
    rules = json.loads(contents["authorization-rules.json"])
    rules.update(json.loads(contents["delivery-rules.json"]))
    Validator = build_validator(rules)
    compiled = {}
    for name, schema in schemas.items():
        inspect_schema(schema)
        Validator.check_schema(schema)
        compiled[name] = Validator(schema, format_checker=format_checker)
    ids = set()
    covered = set()
    for case in fixtures:
        if case["id"] in ids:
            fail("FIXTURE_ID_DUPLICATE")
        ids.add(case["id"])
        if case["schema"] not in compiled:
            fail("FIXTURE_SCHEMA_UNKNOWN")
        if compiled[case["schema"]].is_valid(case["data"]) != case["valid"]:
            # Apenas identificador sintético, nunca dados rejeitados/token/erro raw.
            identifier = case["id"] if re.fullmatch(r"[a-zA-Z0-9._-]+", case["id"]) else "redacted"
            fail("FIXTURE_EXPECTATION_MISMATCH:" + identifier)
        if case["valid"]:
            covered.add(case["schema"])
    if covered != set(schemas):
        fail("SCHEMA_WITHOUT_VALID_FIXTURE")
    valid = sum(case["valid"] for case in fixtures)
    return {"validator": "python-jsonschema+maestro", "total": len(fixtures), "valid": valid, "invalid": len(fixtures) - valid, "schemas": len(schemas)}


if __name__ == "__main__":
    try:
        if len(sys.argv) != 2:
            fail("BUNDLE_PATH_REQUIRED")
        print(json.dumps(validate_bundle(sys.argv[1]), sort_keys=True))
    except ContractError as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
    except Exception:
        print("CONTRACT_VALIDATION_FAILED", file=sys.stderr)
        sys.exit(1)
