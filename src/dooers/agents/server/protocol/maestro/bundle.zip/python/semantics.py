import hashlib
import json
from ada_url import URL

"""Regras relacionais do wire; mapas de política vêm da fonte Zod exportada."""
import re

ECMASCRIPT_WHITESPACE = "\u0009\u000a\u000b\u000c\u000d\u0020\u00a0\u1680\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u2028\u2029\u202f\u205f\u3000\ufeff"


def epoch(value):
    # Date.parse usa calendário gregoriano, aceita ano 0000 e trunca sub-ms.
    match = re.fullmatch(r"([0-9]{4})-([0-9]{2})-([0-9]{2})T([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?Z", value)
    if not match:
        raise ValueError("DATETIME_INVALID")
    year, month, day, hour, minute, second = (int(part or 0) for part in match.groups()[:6])
    fraction = int(((match.group(7) or "") + "000")[:3])
    def preceding_years(y):
        previous = y - 1
        return 365 * previous + previous // 4 - previous // 100 + previous // 400
    leap = year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)
    months = (31, 29 if leap else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
    days = preceding_years(year) - preceding_years(1970) + sum(months[:month - 1]) + day - 1
    return days * 86400000 + hour * 3600000 + minute * 60000 + second * 1000 + fraction


def same_scope(a, b):
    return all(a[key] == b[key] for key in ("organization_id", "scope_kind", "workspace_id"))


def target_key(target):
    return (target["kind"], target["principal_id"], target.get("runtime_id") if target["kind"] == "agent" else None)


def authorization_exchange(value, rules):
    introspection, request, response = (value[key] for key in ("introspection", "request", "response"))
    principal = introspection["principal"]
    if not (request["token_ref"] == response["token_ref"] == introspection["token_ref"]):
        return False
    if any(response["principal"][key] != principal[key] for key in ("actor_type", "principal_id")):
        return False
    if any(request[key] != response[key] for key in ("request_id", "thread_id", "operation")) or not same_scope(request["scope"], response["scope"]):
        return False
    if any(request.get("resource", {}).get(key) != response.get("resource", {}).get(key) for key in ("event_id", "root_event_id", "artifact_id", "interaction_id", "delivery_id", "execution_id")):
        return False
    asked = [target_key(target) for target in request["targets"]]
    received = [target_key(result["target"]) for result in response["targets"]]
    if len(asked) != len(received) or len(set(received)) != len(asked) or set(asked) != set(received):
        return False
    if not response["allowed"]:
        return True
    if not same_scope(introspection["scope"], request["scope"]) or response["authorization_version"] != introspection["authorization_version"]:
        return False
    now = epoch(value["evaluated_at"])
    if not (epoch(introspection["issued_at"]) <= now < epoch(introspection["expires_at"])):
        return False
    if not (now < epoch(response["valid_until"]) <= min(epoch(introspection["expires_at"]), now + 60000)):
        return False
    operation = request["operation"]
    required = list(rules["authorizationScopeRules"][operation])
    if operation == "delivery.complete" and request.get("writes_output"):
        required.append("responses:write")
    if principal["actor_type"] == "aiagent":
        if operation in ("artifact.upload", "artifact.complete", "artifact.link"):
            required = ["responses:write"]
        elif operation in ("artifact.read", "artifact.download"):
            required = ["deliveries:read", "context:read"]
        elif not operation.startswith("delivery."):
            return False
        runtime = response["context"].get("runtime")
        if not runtime or runtime["instance_agent_id"] != principal["principal_id"] or runtime["runtime_id"] != principal["runtime_id"]:
            return False
        if request.get("runtime_id") and request["runtime_id"] != runtime["runtime_id"]:
            return False
    elif operation.startswith("delivery."):
        return False
    if not set(required).issubset(introspection["scopes"]):
        return False
    if operation.startswith("thread.supervision."):
        policy = response["context"].get("supervision")
        if policy:
            required_reason = policy["mode"] == "strict" or (policy["mode"] == "operational" and request["scope"]["scope_kind"] == "personal")
            if policy["reason_required"] != required_reason or (required_reason and not request.get("supervision", {}).get("access_reason")):
                return False
    return True


def delivery_semantic(name, value, rules):
    def current_token(claims, now):
        return claims["iat"] * 1000 <= epoch(now) < claims["exp"] * 1000
    def claim_time(claims):
        return 0 < claims["exp"] - claims["iat"] <= 300 and claims["exp"] * 1000 <= epoch(claims["deadline_at"])
    def same_binding(left, right):
        return all(left[key] == right[key] for key in rules["deliveryBindingKeys"])
    if name == "delivery_trusted_url":
        parsed = URL(value)
        return not (parsed.username or parsed.password or parsed.search or parsed.hash) and (parsed.protocol == "https:" or parsed.hostname in ("localhost", "127.0.0.1", "[::1]"))
    if name == "delivery_envelope":
        if value["phase_retry_number"] >= value["attempt_number"] or epoch(value["deadline_at"]) > epoch(value["delivery_expires_at"]):
            return False
        resume = value.get("resume")
        if resume is None:
            return value["phase_id"] == "initial" and value["context_cutoff_sequence"] == value["trigger_sequence"]
        return value["phase_id"] == resume["interaction_id"] and value["attempt_number"] >= 2 and value["execution_id"] != resume["resume_of_execution_id"] and value["trigger_event_id"] == resume["original_trigger_event_id"] and value["context_cutoff_sequence"] == resume["response_sequence"] and int(value["context_cutoff_sequence"]) > int(value["trigger_sequence"])
    if name == "delivery_claim_time":
        return claim_time(value)
    if name == "delivery_capability_claims":
        return claim_time(value) and value["sub"] == value["instance_agent_id"]
    if name == "delivery_dispatch_binding":
        body, dispatch, capability = value["envelope"], value["dispatch_claims"], value["capability_claims"]
        def normalize(item):
            if isinstance(item, dict): return {key: normalize(child) for key, child in item.items()}
            if isinstance(item, list): return [normalize(child) for child in item]
            if isinstance(item, float) and item.is_integer(): return int(item)
            return item
        canonical = json.dumps(normalize(body), sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8", errors="backslashreplace")
        return value["dispatch_header"]["kid"] in value["trusted_key_ids"] and value["capability_header"]["kid"] in value["trusted_key_ids"] and same_binding(body, dispatch) and same_binding(body, capability) and dispatch["body_sha256"] == hashlib.sha256(canonical).hexdigest() and dispatch["aud"] == value["configured_runtime_endpoint"] and body["callback_base_url"] == value["configured_callback_base_url"] and body["instance_agent_id"] == value["authorized_instance_agent_id"] and body["runtime_id"] == value["authorized_runtime_id"] and current_token(dispatch, value["now"]) and current_token(capability, value["now"])
    if name == "delivery_callback_binding":
        current, capability, agent = value["current"], value["capability_claims"], value["agent_claims"]
        return same_binding(current, capability) and value["request_lease_fence"] == current["lease_fence"] and value["operation"] in capability["operations"] and agent["agent_id"] == current["instance_agent_id"] and agent["runtime_id"] == current["runtime_id"] and agent["organization_id"] == current["organization_id"] and agent["workspace_id"] == current["workspace_id"] and current_token(capability, value["db_now"]) and current_token(agent, value["db_now"]) and all(epoch(value["db_now"]) < epoch(current[key]) for key in ("lease_until", "deadline_at", "delivery_expires_at"))
    if name in ("delivery_state_transition", "delivery_execution_transition", "delivery_phase_transition"):
        table = rules[{"delivery_state_transition": "deliveryTransitions", "delivery_execution_transition": "executionTransitions", "delivery_phase_transition": "phaseTransitions"}[name]]
        return [value["from"], value["to"]] in table[value["event"]]
    if name == "delivery_phase_advance":
        previous, next_ = value["previous"], value["next"]
        if any(previous[key] != next_[key] for key in ("delivery_id", "trigger_event_id", "trigger_sequence")) or previous["execution_id"] == next_["execution_id"] or next_["attempt_number"] != previous["attempt_number"] + 1 or int(next_["lease_fence"]) <= int(previous["lease_fence"]): return False
        if value["kind"] == "retry":
            return value["interaction_id"] is None and value["response_sequence"] is None and next_["phase_id"] == previous["phase_id"] and next_["phase_retry_number"] == previous["phase_retry_number"] + 1 and next_["context_cutoff_sequence"] == previous["context_cutoff_sequence"]
        return value["interaction_id"] is not None and value["response_sequence"] is not None and next_["phase_id"] == value["interaction_id"] and next_["phase_id"] != previous["phase_id"] and next_["phase_retry_number"] == 0 and next_["context_cutoff_sequence"] == value["response_sequence"] and int(value["response_sequence"]) > int(previous["context_cutoff_sequence"])
    if name == "delivery_output_identity":
        ordinal = int(value["ordinal"])
        return value["output_id"] == f"output:{ordinal}" and value["operation_id"] == f"effect:{ordinal}" and value["effect_key"] == f"maestro:v1:effect:{value['delivery_id']}:{value['phase_id']}:{ordinal}"
    if name == "delivery_callback_idempotency":
        prefix = f"{value['operation']}:{value['delivery_id']}:{value['phase_id']}"
        return value["ordinal"] is None and value["key"] == prefix if value["operation"] == "complete" else value["ordinal"] is not None and value["key"] == f"{prefix}:{int(value['ordinal'])}"
    if name == "delivery_output_replay":
        if value["stored_hash"] is None:
            return value["stored_event_id"] is None and value["result_event_id"] is not None and value["result"] == "persisted" and value["new_event_count"] == 1 and not value["automatic_retry"]
        if value["stored_event_id"] is None: return False
        if value["stored_hash"] == value["submitted_hash"]:
            return value["result"] == "duplicate" and value["result_event_id"] == value["stored_event_id"] and value["new_event_count"] == 0 and not value["automatic_retry"]
        return value["result"] == "IDEMPOTENCY_CONFLICT" and value["result_event_id"] is None and value["new_event_count"] == 0 and not value["automatic_retry"]
    if name == "delivery_durable_result":
        state, attempt = value["delivery_state"], value["execution_state"]
        if value["response"]["state"] != state or not set(value["durable_message_event_ids"]).issubset(value["response"]["result_event_ids"]): return False
        if state == "waiting_input": return attempt == "suspended" and value["interaction_id"] is not None
        if value["interaction_id"] is not None: return False
        if state == "responded": return attempt == "completed" and bool(value["durable_message_event_ids"])
        if state == "silent": return attempt == "completed" and not value["durable_message_event_ids"]
        if state == "failed": return attempt in ("failed", "timed_out")
        return state == "canceled" and attempt == "canceled"
    if name == "delivery_interaction_decision":
        expired = epoch(value["db_now"]) >= min(epoch(value["interaction_expires_at"]), epoch(value["delivery_expires_at"]))
        if value["action"] == "expire": return expired and value["after"] == "expired" and not value["resume_scheduled"]
        if expired: return False
        if value["action"] in ("cancel", "reject"): return value["after"] == "canceled" and not value["resume_scheduled"]
        return value["after"] == "pending" and value["resume_scheduled"]
    if name == "delivery_ack_recovery":
        if value["persisted_state"] in ("responded", "silent", "failed", "canceled", "expired", "waiting_input"):
            return value["action"] == "return_persisted" and not value["new_execution"]
        if value["persisted_state"] != "running": return False
        return value["action"] == ("wait" if value["lease_valid"] else "recover_after_invalidation") and not value["new_execution"]
    raise ValueError("SEMANTIC_RULE_UNKNOWN")


def semantic_valid(name, value, rules):
    if name.startswith("delivery_"):
        return delivery_semantic(name, value, rules)
    if name == "nonblank-content":
        return any(part["type"] == "attachment" or part["text"].strip(ECMASCRIPT_WHITESPACE) for part in value)
    if name in ("unique-option-participant", "unique-form-field"):
        key = "participant_id" if name == "unique-option-participant" else "name"
        return len({item[key] for item in value}) == len(value)
    if name == "publication-exchange":
        http, ws = value["http"]["body"], value["ws"]["payload"]
        if not (value["idempotency_key"] == value["http"]["headers"]["Idempotency-Key"] == http["client_event_id"] == ws["client_event_id"] and value["thread_id"] == ws["thread_id"]):
            return False
        return all(http.get(key, []) == ws.get(key, []) for key in ("content", "mentions", "agent_options"))
    if name in ("identity_human_claims", "identity_agent_claims"):
        return value["sub"] == value["user_id" if name == "identity_human_claims" else "agent_id"] and 0 < value["exp"] - value["iat"] <= 300
    if name == "identity_agent_lineage":
        return value["principal"]["principal_id"] == value["lineage"]["agent_id"] and value["principal"]["runtime_id"] == value["lineage"]["runtime_id"] and value["authorization_version"] == value["lineage"]["authorization_version"]
    if name in ("identity_introspection_time", "identity_supervision_grant"):
        return 0 < epoch(value["expires_at"]) - epoch(value["issued_at"]) <= (300000 if name == "identity_introspection_time" else 60000)
    if name == "identity_participant_role":
        return not (value["target"]["kind"] == "agent" and value["role"] == "owner")
    if name == "identity_authorize_request":
        operation = value["operation"]
        if value["thread_id"] is None and operation not in ("thread.create", "thread.list", "thread.supervision.list", "artifact.upload.prethread"):
            return False
        if operation.startswith("thread.supervision.") and not value.get("supervision"):
            return False
        if "writes_output" in value and operation not in ("delivery.complete", "delivery.suspend"):
            return False
        return len({(target["kind"], target["principal_id"]) for target in value["targets"]}) == len(value["targets"])
    if name == "identity_runtime_capabilities":
        return set(rules["requiredRuntimeCapabilities"]).issubset(value["capabilities"])
    if name == "identity_allowed_authorization":
        if not all(target["allowed"] for target in value["targets"]):
            return False
        if value["principal"]["actor_type"] == "aiagent" and value["operation"].startswith("delivery."):
            runtime = value["context"].get("runtime")
            if not runtime or runtime["instance_agent_id"] != value["principal"]["principal_id"] or runtime["runtime_id"] != value["principal"]["runtime_id"]:
                return False
        return not value["operation"].startswith("thread.supervision.") or bool(value["context"].get("supervision"))
    if name == "identity_agent_candidate":
        return not value["eligible"] or (value["thread_management"] == "maestro" and value["maestro_protocol_version"] == 1 and value["availability"] == "available" and set(rules["requiredRuntimeCapabilities"]).issubset(value["capabilities"]))
    if name == "identity_candidate_reason":
        return not value["eligible"] or "reason_code" not in value
    if name == "identity_candidates_page":
        return value["has_more"] == (value["next_cursor"] is not None)
    if name == "identity_authorization_exchange":
        return authorization_exchange(value, rules)
    raise ValueError("SEMANTIC_RULE_UNKNOWN")


SEMANTIC_RULES = frozenset((
    "delivery_trusted_url", "delivery_envelope", "delivery_claim_time", "delivery_capability_claims",
    "delivery_dispatch_binding", "delivery_callback_binding", "delivery_state_transition", "delivery_execution_transition",
    "delivery_phase_transition", "delivery_phase_advance", "delivery_output_identity", "delivery_output_replay", "delivery_durable_result", "delivery_callback_idempotency",
    "delivery_interaction_decision", "delivery_ack_recovery",
    "nonblank-content", "unique-option-participant", "unique-form-field", "publication-exchange",
    "identity_human_claims", "identity_agent_claims", "identity_agent_lineage", "identity_introspection_time",
    "identity_participant_role", "identity_authorize_request", "identity_runtime_capabilities",
    "identity_allowed_authorization", "identity_agent_candidate", "identity_candidate_reason",
    "identity_candidates_page", "identity_supervision_grant", "identity_authorization_exchange",
))
